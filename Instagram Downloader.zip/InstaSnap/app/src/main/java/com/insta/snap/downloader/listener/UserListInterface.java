package com.insta.snap.downloader.listener;

import com.insta.snap.downloader.api.model.NodeModel;
import com.insta.snap.downloader.api.model.TrayModel;

public interface UserListInterface {
    void FacebookUserListClick(int i, NodeModel nodeModel);

    void FacebookUserListClick(int i, TrayModel trayModel);
}