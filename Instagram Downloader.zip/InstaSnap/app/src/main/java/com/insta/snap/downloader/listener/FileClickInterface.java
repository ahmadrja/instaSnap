package com.insta.snap.downloader.listener;

import java.io.File;

public interface FileClickInterface {
    void getPosition(int position, File file);
}
